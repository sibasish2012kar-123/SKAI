// SKI AI backend for Cloudflare Workers.
// Store OPENAI_API_KEY as a Worker secret. Never expose it in frontend code.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // Before public launch, restrict this to your exact website origin.
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8"
};
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, {headers:corsHeaders});
    if (url.pathname !== "/api/chat") return json({error:"Not found"},404);
    if (request.method !== "POST") return json({error:"Use POST"},405);
    if (!env.OPENAI_API_KEY) return json({error:"Backend API key is not configured."},500);
    let body;
    try { body = await request.json(); } catch { return json({error:"Invalid JSON."},400); }
    if (!Array.isArray(body.messages)) return json({error:"messages must be an array."},400);
    const messages = body.messages.filter(m=>m&&["user","assistant"].includes(m.role)&&typeof m.content==="string").slice(-12);
    if (!messages.length) return json({error:"Please send a message."},400);
    if (messages.some(m=>m.content.length>4000)) return json({error:"A message is too long."},400);
    try {
      const upstream = await fetch("https://api.openai.com/v1/responses", {
        method:"POST",
        headers:{"Authorization":`Bearer ${env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"gpt-4.1-mini",
          instructions:"You are SKI AI, a helpful, clear, honest AI assistant. Explain things simply. If uncertain, say so.",
          input:messages.map(m=>({role:m.role,content:[{type:"input_text",text:m.content}]})),
          max_output_tokens:700
        })
      });
      const data = await upstream.json().catch(()=>({}));
      if (!upstream.ok) return json({error:"AI service failed. Check API access, model availability, and billing."},502);
      let reply = typeof data.output_text==="string" ? data.output_text : "";
      if (!reply && Array.isArray(data.output)) reply=data.output.flatMap(x=>Array.isArray(x.content)?x.content:[]).filter(x=>x.type==="output_text"&&typeof x.text==="string").map(x=>x.text).join("\n");
      if (!reply) return json({error:"The AI service returned an empty answer."},502);
      return json({reply},200);
    } catch { return json({error:"Could not reach the AI service. Try again later."},502); }
  }
};
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:corsHeaders});}
